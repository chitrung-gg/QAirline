--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE qairline;
--
-- Name: qairline; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE qairline WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Vietnamese_Vietnam.1258';


ALTER DATABASE qairline OWNER TO postgres;

\connect qairline

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aboutus_category_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.aboutus_category_enum AS ENUM (
    'Achievement',
    'Intro',
    'OurValue',
    'OurVision'
);


ALTER TYPE public.aboutus_category_enum OWNER TO postgres;

--
-- Name: aircraft_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.aircraft_status_enum AS ENUM (
    'Active',
    'Maintenance',
    'Retired'
);


ALTER TYPE public.aircraft_status_enum OWNER TO postgres;

--
-- Name: booking_bookingstatus_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.booking_bookingstatus_enum AS ENUM (
    'Confirmed',
    'Pending',
    'Cancelled'
);


ALTER TYPE public.booking_bookingstatus_enum OWNER TO postgres;

--
-- Name: booking_paymentstatus_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.booking_paymentstatus_enum AS ENUM (
    'Paid',
    'Pending',
    'Unpaid'
);


ALTER TYPE public.booking_paymentstatus_enum OWNER TO postgres;

--
-- Name: flight_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.flight_status_enum AS ENUM (
    'Scheduled',
    'Arrived',
    'Delayed',
    'Cancelled'
);


ALTER TYPE public.flight_status_enum OWNER TO postgres;

--
-- Name: news_category_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.news_category_enum AS ENUM (
    'Updates',
    'Announcements',
    'Tips'
);


ALTER TYPE public.news_category_enum OWNER TO postgres;

--
-- Name: payment_paymentstatus_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.payment_paymentstatus_enum AS ENUM (
    'Paid',
    'Refunded',
    'Failed',
    'Pending'
);


ALTER TYPE public.payment_paymentstatus_enum OWNER TO postgres;

--
-- Name: promotion_discounttype_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.promotion_discounttype_enum AS ENUM (
    'Percentage',
    'FixedAmount'
);


ALTER TYPE public.promotion_discounttype_enum OWNER TO postgres;

--
-- Name: user_gender_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_gender_enum AS ENUM (
    'Male',
    'Female',
    'Other'
);


ALTER TYPE public.user_gender_enum OWNER TO postgres;

--
-- Name: user_role_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role_enum AS ENUM (
    'Admin',
    'User'
);


ALTER TYPE public.user_role_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aboutus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aboutus (
    id integer NOT NULL,
    category public.aboutus_category_enum NOT NULL,
    title character varying(255) NOT NULL,
    content text[] NOT NULL,
    image text[],
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.aboutus OWNER TO postgres;

--
-- Name: aboutus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aboutus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aboutus_id_seq OWNER TO postgres;

--
-- Name: aboutus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.aboutus_id_seq OWNED BY public.aboutus.id;


--
-- Name: aircraft; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aircraft (
    id integer NOT NULL,
    "aircraftCode" character varying(50) NOT NULL,
    model character varying(100) NOT NULL,
    manufacturer character varying(100) NOT NULL,
    capacity integer NOT NULL,
    "seatClasses" jsonb NOT NULL,
    status public.aircraft_status_enum DEFAULT 'Active'::public.aircraft_status_enum NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.aircraft OWNER TO postgres;

--
-- Name: aircraft_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aircraft_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aircraft_id_seq OWNER TO postgres;

--
-- Name: aircraft_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.aircraft_id_seq OWNED BY public.aircraft.id;


--
-- Name: airport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airport (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    city character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    "iataCode" character varying(10) NOT NULL
);


ALTER TABLE public.airport OWNER TO postgres;

--
-- Name: airport_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.airport_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.airport_id_seq OWNER TO postgres;

--
-- Name: airport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.airport_id_seq OWNED BY public.airport.id;


--
-- Name: booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking (
    id integer NOT NULL,
    "passengerName" character varying(255) NOT NULL,
    "passengerEmail" character varying(100) NOT NULL,
    "passengerDob" timestamp without time zone NOT NULL,
    "passportNumber" character varying(50) NOT NULL,
    "bookingCode" character varying(50),
    "ticketPrice" jsonb NOT NULL,
    "totalPrice" double precision,
    "passengerNumber" integer,
    "seatClass" character varying(50) NOT NULL,
    "bookingDate" timestamp without time zone DEFAULT now(),
    "bookingStatus" public.booking_bookingstatus_enum DEFAULT 'Pending'::public.booking_bookingstatus_enum NOT NULL,
    "paymentStatus" public.booking_paymentstatus_enum DEFAULT 'Pending'::public.booking_paymentstatus_enum NOT NULL,
    "userId" integer,
    "flightId" integer,
    "promotionId" integer
);


ALTER TABLE public.booking OWNER TO postgres;

--
-- Name: booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.booking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.booking_id_seq OWNER TO postgres;

--
-- Name: booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.booking_id_seq OWNED BY public.booking.id;


--
-- Name: destination; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.destination (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    image character varying(255),
    city character varying(100) NOT NULL,
    country character varying(100) NOT NULL
);


ALTER TABLE public.destination OWNER TO postgres;

--
-- Name: destination_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.destination_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.destination_id_seq OWNER TO postgres;

--
-- Name: destination_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.destination_id_seq OWNED BY public.destination.id;


--
-- Name: faq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faq (
    id integer NOT NULL,
    question character varying(255) NOT NULL,
    answer text NOT NULL,
    category character varying(100),
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    language character varying(10) DEFAULT 'vi'::character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.faq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faq_id_seq OWNER TO postgres;

--
-- Name: faq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faq_id_seq OWNED BY public.faq.id;


--
-- Name: flight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight (
    id integer NOT NULL,
    "flightNumber" character varying NOT NULL,
    "departureTime" timestamp without time zone NOT NULL,
    "arrivalTime" timestamp without time zone NOT NULL,
    status public.flight_status_enum DEFAULT 'Scheduled'::public.flight_status_enum NOT NULL,
    "availableSeats" integer NOT NULL,
    "seatClasses" jsonb NOT NULL,
    duration double precision,
    "baseClassPrice" jsonb,
    "aircraftId" integer,
    "departureAirportId" integer,
    "arrivalAirportId" integer
);


ALTER TABLE public.flight OWNER TO postgres;

--
-- Name: flight_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.flight_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.flight_id_seq OWNER TO postgres;

--
-- Name: flight_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.flight_id_seq OWNED BY public.flight.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.news (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    category public.news_category_enum DEFAULT 'Announcements'::public.news_category_enum NOT NULL,
    "coverImage" character varying(255),
    "isPublished" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.news OWNER TO postgres;

--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.news_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_id_seq OWNER TO postgres;

--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    id integer NOT NULL,
    amount double precision NOT NULL,
    "paymentStatus" public.payment_paymentstatus_enum NOT NULL,
    "paymentMethod" character varying(50) NOT NULL,
    "transactionId" character varying(100),
    "paymentDate" timestamp without time zone NOT NULL,
    "isRefunded" boolean DEFAULT false NOT NULL,
    "refundAmount" double precision,
    "refundDate" timestamp without time zone,
    "bookingId" integer
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_id_seq OWNER TO postgres;

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_id_seq OWNED BY public.payment.id;


--
-- Name: policy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policy (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    "treeContent" jsonb,
    category character varying(100),
    "isActive" boolean DEFAULT true NOT NULL,
    language character varying(10) DEFAULT 'vi'::character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.policy OWNER TO postgres;

--
-- Name: policy_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.policy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.policy_id_seq OWNER TO postgres;

--
-- Name: policy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.policy_id_seq OWNED BY public.policy.id;


--
-- Name: promotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    description text NOT NULL,
    "coverImage" character varying(255),
    "startDate" timestamp without time zone NOT NULL,
    "endDate" timestamp without time zone NOT NULL,
    discount integer NOT NULL,
    "discountType" public.promotion_discounttype_enum NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public.promotion OWNER TO postgres;

--
-- Name: promotion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promotion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.promotion_id_seq OWNER TO postgres;

--
-- Name: promotion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.promotion_id_seq OWNED BY public.promotion.id;


--
-- Name: refresh_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_token (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    token character varying NOT NULL,
    "userId" integer NOT NULL,
    "expiryDate" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.refresh_token OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    "phoneNumber" character varying(20),
    "firstName" character varying(50),
    "lastName" character varying(50),
    dob timestamp without time zone,
    gender public.user_gender_enum,
    address character varying(255),
    "passportNumber" character varying(20),
    role public.user_role_enum DEFAULT 'User'::public.user_role_enum NOT NULL,
    "accessToken" character varying(255),
    "refreshToken" character varying(255)
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: verification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification (
    id integer NOT NULL,
    token character varying NOT NULL,
    "expiresAt" timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    "userId" integer
);


ALTER TABLE public.verification OWNER TO postgres;

--
-- Name: verification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.verification_id_seq OWNER TO postgres;

--
-- Name: verification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verification_id_seq OWNED BY public.verification.id;


--
-- Name: aboutus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aboutus ALTER COLUMN id SET DEFAULT nextval('public.aboutus_id_seq'::regclass);


--
-- Name: aircraft id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aircraft ALTER COLUMN id SET DEFAULT nextval('public.aircraft_id_seq'::regclass);


--
-- Name: airport id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport ALTER COLUMN id SET DEFAULT nextval('public.airport_id_seq'::regclass);


--
-- Name: booking id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking ALTER COLUMN id SET DEFAULT nextval('public.booking_id_seq'::regclass);


--
-- Name: destination id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.destination ALTER COLUMN id SET DEFAULT nextval('public.destination_id_seq'::regclass);


--
-- Name: faq id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq ALTER COLUMN id SET DEFAULT nextval('public.faq_id_seq'::regclass);


--
-- Name: flight id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight ALTER COLUMN id SET DEFAULT nextval('public.flight_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment ALTER COLUMN id SET DEFAULT nextval('public.payment_id_seq'::regclass);


--
-- Name: policy id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy ALTER COLUMN id SET DEFAULT nextval('public.policy_id_seq'::regclass);


--
-- Name: promotion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion ALTER COLUMN id SET DEFAULT nextval('public.promotion_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: verification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification ALTER COLUMN id SET DEFAULT nextval('public.verification_id_seq'::regclass);


--
-- Data for Name: aboutus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aboutus (id, category, title, content, image, "isActive", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.aboutus (id, category, title, content, image, "isActive", "createdAt", "updatedAt") FROM '$$PATH$$/5088.dat';

--
-- Data for Name: aircraft; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aircraft (id, "aircraftCode", model, manufacturer, capacity, "seatClasses", status, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.aircraft (id, "aircraftCode", model, manufacturer, capacity, "seatClasses", status, "createdAt", "updatedAt") FROM '$$PATH$$/5090.dat';

--
-- Data for Name: airport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airport (id, name, city, country, "iataCode") FROM stdin;
\.
COPY public.airport (id, name, city, country, "iataCode") FROM '$$PATH$$/5092.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booking (id, "passengerName", "passengerEmail", "passengerDob", "passportNumber", "bookingCode", "ticketPrice", "totalPrice", "passengerNumber", "seatClass", "bookingDate", "bookingStatus", "paymentStatus", "userId", "flightId", "promotionId") FROM stdin;
\.
COPY public.booking (id, "passengerName", "passengerEmail", "passengerDob", "passportNumber", "bookingCode", "ticketPrice", "totalPrice", "passengerNumber", "seatClass", "bookingDate", "bookingStatus", "paymentStatus", "userId", "flightId", "promotionId") FROM '$$PATH$$/5094.dat';

--
-- Data for Name: destination; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.destination (id, name, description, image, city, country) FROM stdin;
\.
COPY public.destination (id, name, description, image, city, country) FROM '$$PATH$$/5096.dat';

--
-- Data for Name: faq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faq (id, question, answer, category, "sortOrder", "isActive", language, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.faq (id, question, answer, category, "sortOrder", "isActive", language, "createdAt", "updatedAt") FROM '$$PATH$$/5098.dat';

--
-- Data for Name: flight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight (id, "flightNumber", "departureTime", "arrivalTime", status, "availableSeats", "seatClasses", duration, "baseClassPrice", "aircraftId", "departureAirportId", "arrivalAirportId") FROM stdin;
\.
COPY public.flight (id, "flightNumber", "departureTime", "arrivalTime", status, "availableSeats", "seatClasses", duration, "baseClassPrice", "aircraftId", "departureAirportId", "arrivalAirportId") FROM '$$PATH$$/5100.dat';

--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.news (id, title, content, category, "coverImage", "isPublished", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.news (id, title, content, category, "coverImage", "isPublished", "createdAt", "updatedAt") FROM '$$PATH$$/5102.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (id, amount, "paymentStatus", "paymentMethod", "transactionId", "paymentDate", "isRefunded", "refundAmount", "refundDate", "bookingId") FROM stdin;
\.
COPY public.payment (id, amount, "paymentStatus", "paymentMethod", "transactionId", "paymentDate", "isRefunded", "refundAmount", "refundDate", "bookingId") FROM '$$PATH$$/5104.dat';

--
-- Data for Name: policy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.policy (id, title, "treeContent", category, "isActive", language, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.policy (id, title, "treeContent", category, "isActive", language, "createdAt", "updatedAt") FROM '$$PATH$$/5106.dat';

--
-- Data for Name: promotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion (id, code, description, "coverImage", "startDate", "endDate", discount, "discountType", "isActive") FROM stdin;
\.
COPY public.promotion (id, code, description, "coverImage", "startDate", "endDate", discount, "discountType", "isActive") FROM '$$PATH$$/5108.dat';

--
-- Data for Name: refresh_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_token (id, token, "userId", "expiryDate") FROM stdin;
\.
COPY public.refresh_token (id, token, "userId", "expiryDate") FROM '$$PATH$$/5110.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, email, username, password, "phoneNumber", "firstName", "lastName", dob, gender, address, "passportNumber", role, "accessToken", "refreshToken") FROM stdin;
\.
COPY public."user" (id, email, username, password, "phoneNumber", "firstName", "lastName", dob, gender, address, "passportNumber", role, "accessToken", "refreshToken") FROM '$$PATH$$/5111.dat';

--
-- Data for Name: verification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification (id, token, "expiresAt", "createdAt", "updatedAt", "userId") FROM stdin;
\.
COPY public.verification (id, token, "expiresAt", "createdAt", "updatedAt", "userId") FROM '$$PATH$$/5113.dat';

--
-- Name: aboutus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aboutus_id_seq', 4, true);


--
-- Name: aircraft_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aircraft_id_seq', 2, true);


--
-- Name: airport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.airport_id_seq', 4, true);


--
-- Name: booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.booking_id_seq', 5, true);


--
-- Name: destination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.destination_id_seq', 4, true);


--
-- Name: faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faq_id_seq', 5, true);


--
-- Name: flight_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.flight_id_seq', 5, true);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.news_id_seq', 3, true);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_id_seq', 1, false);


--
-- Name: policy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.policy_id_seq', 1, true);


--
-- Name: promotion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promotion_id_seq', 2, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 2, true);


--
-- Name: verification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verification_id_seq', 1, false);


--
-- Name: news PK_39a43dfcb6007180f04aff2357e; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT "PK_39a43dfcb6007180f04aff2357e" PRIMARY KEY (id);


--
-- Name: aircraft PK_46f8c680e9ff88a752b7834bba4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aircraft
    ADD CONSTRAINT "PK_46f8c680e9ff88a752b7834bba4" PRIMARY KEY (id);


--
-- Name: booking PK_49171efc69702ed84c812f33540; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "PK_49171efc69702ed84c812f33540" PRIMARY KEY (id);


--
-- Name: policy PK_9917b0c5e4286703cc656b1d39f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT "PK_9917b0c5e4286703cc656b1d39f" PRIMARY KEY (id);


--
-- Name: refresh_token PK_b575dd3c21fb0831013c909e7fe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT "PK_b575dd3c21fb0831013c909e7fe" PRIMARY KEY (id);


--
-- Name: flight PK_bf571ce6731cf071fc51b94df03; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT "PK_bf571ce6731cf071fc51b94df03" PRIMARY KEY (id);


--
-- Name: user PK_cace4a159ff9f2512dd42373760; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY (id);


--
-- Name: faq PK_d6f5a52b1a96dd8d0591f9fbc47; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faq
    ADD CONSTRAINT "PK_d6f5a52b1a96dd8d0591f9fbc47" PRIMARY KEY (id);


--
-- Name: aboutus PK_dcb4312481d4da3caf80364246a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aboutus
    ADD CONSTRAINT "PK_dcb4312481d4da3caf80364246a" PRIMARY KEY (id);


--
-- Name: destination PK_e45b5ee5788eb3c7f0ae41746e7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.destination
    ADD CONSTRAINT "PK_e45b5ee5788eb3c7f0ae41746e7" PRIMARY KEY (id);


--
-- Name: airport PK_ea1ecba8dec9bee0cb60194e788; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT "PK_ea1ecba8dec9bee0cb60194e788" PRIMARY KEY (id);


--
-- Name: verification PK_f7e3a90ca384e71d6e2e93bb340; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT "PK_f7e3a90ca384e71d6e2e93bb340" PRIMARY KEY (id);


--
-- Name: promotion PK_fab3630e0789a2002f1cadb7d38; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT "PK_fab3630e0789a2002f1cadb7d38" PRIMARY KEY (id);


--
-- Name: payment PK_fcaec7df5adf9cac408c686b2ab; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "PK_fcaec7df5adf9cac408c686b2ab" PRIMARY KEY (id);


--
-- Name: aircraft UQ_12a15a51f405ab178834d2c30f4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aircraft
    ADD CONSTRAINT "UQ_12a15a51f405ab178834d2c30f4" UNIQUE ("aircraftCode");


--
-- Name: user UQ_78a916df40e02a9deb1c4b75edb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "UQ_78a916df40e02a9deb1c4b75edb" UNIQUE (username);


--
-- Name: promotion UQ_969359329a22440d2b8f7d491d4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT "UQ_969359329a22440d2b8f7d491d4" UNIQUE (code);


--
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e22; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE (email);


--
-- Name: flight UQ_f3e21c00ba40ed321afed8dc1e1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT "UQ_f3e21c00ba40ed321afed8dc1e1" UNIQUE ("flightNumber");


--
-- Name: aircraftIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "aircraftIndex" ON public.flight USING btree ("aircraftId");


--
-- Name: arrivalAirportIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "arrivalAirportIndex" ON public.flight USING btree ("arrivalAirportId");


--
-- Name: bookingIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "bookingIndex" ON public.payment USING btree ("bookingId");


--
-- Name: departureAirportIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "departureAirportIndex" ON public.flight USING btree ("departureAirportId");


--
-- Name: flightIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "flightIndex" ON public.booking USING btree ("flightId");


--
-- Name: promotionIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "promotionIndex" ON public.booking USING btree ("promotionId");


--
-- Name: userIndex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "userIndex" ON public.booking USING btree ("userId");


--
-- Name: booking FK_336b3f4a235460dc93645fbf222; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "FK_336b3f4a235460dc93645fbf222" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flight FK_3a0c5e1517f31f39132ab8ed209; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT "FK_3a0c5e1517f31f39132ab8ed209" FOREIGN KEY ("departureAirportId") REFERENCES public.airport(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flight FK_3a5f8316023020b144289e80e4a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT "FK_3a5f8316023020b144289e80e4a" FOREIGN KEY ("arrivalAirportId") REFERENCES public.airport(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment FK_5738278c92c15e1ec9d27e3a098; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT "FK_5738278c92c15e1ec9d27e3a098" FOREIGN KEY ("bookingId") REFERENCES public.booking(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking FK_671b622f13b29bd20135a0fb130; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "FK_671b622f13b29bd20135a0fb130" FOREIGN KEY ("promotionId") REFERENCES public.promotion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: verification FK_8300048608d8721aea27747b07a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT "FK_8300048608d8721aea27747b07a" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking FK_cc8ec8fa07ca411f70625d36f87; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "FK_cc8ec8fa07ca411f70625d36f87" FOREIGN KEY ("flightId") REFERENCES public.flight(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flight FK_df523f694abea3ed793a8aef725; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT "FK_df523f694abea3ed793a8aef725" FOREIGN KEY ("aircraftId") REFERENCES public.aircraft(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

